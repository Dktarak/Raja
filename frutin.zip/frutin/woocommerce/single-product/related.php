<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce/Templates
 * @version     3.9.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if( class_exists('ReduxFramework') ) {
    $frutin_woo_relproduct_display = frutin_opt('frutin_woo_relproduct_display');
    $frutin_woo_relproduct_num = frutin_opt('frutin_woo_relproduct_num');
    $frutin_woo_relproduct_slider = frutin_opt('frutin_woo_relproduct_slider');

    $subtitle = frutin_opt('frutin_woo_relproduct_subtitle');
    $title = frutin_opt('frutin_woo_relproduct_title');
}else{
    $frutin_woo_relproduct_display ='';
    $frutin_woo_relproduct_num = '';
    $frutin_woo_relproduct_slider = '';

    $subtitle = esc_html__('Similar Product','frutin');
    $title = esc_html__('Related Shop','frutin');
}
$slider_active = $frutin_woo_relproduct_slider ? 'swiper th-slider has-shadow' : '';

if ( $related_products && $frutin_woo_relproduct_display) : ?>

    <div class="space-extra-top arrow-wrap">

        <div class="title-area text-center">
            <?php if(!empty($subtitle)): ?>
                <span class="sub-title"><?php echo esc_html($subtitle) ?></span>
            <?php endif; ?>
            <h2 class="sec-title"><?php echo esc_html($title) ?></h2>
        </div>
        
        <div class="slider-area mb-30">
            <div class="<?php echo esc_attr($slider_active);?>" id="reletedProductSlider" data-slider-options='{"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"2"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"3"},"1200":{"slidesPerView":"4"}}}'>

                <?php
                if ($frutin_woo_relproduct_slider == 1) { ?>
                <div class="swiper-wrapper">
                    <?php
                        $frutin_woo_product_col_val = 'swiper-slide';
                    } else { ?>
                        <div class="row gy-4">
                        <?php 
                        if( class_exists('ReduxFramework') ) {
                            $frutin_woo_related_product_col = frutin_opt('frutin_woo_related_product_col');
                            if( $frutin_woo_related_product_col == '2' ) {
                                $frutin_woo_product_col_val = 'col-xl-2 col-lg-4 col-sm-6';
                            } elseif( $frutin_woo_related_product_col == '3' ) {
                                $frutin_woo_product_col_val = 'col-xl-3 col-lg-4 col-sm-6';
                            } elseif( $frutin_woo_related_product_col == '4' ) {
                                $frutin_woo_product_col_val = 'col-xl-4 col-lg-4 col-sm-6';
                            } elseif( $frutin_woo_related_product_col == '6' ) {
                                $frutin_woo_product_col_val = 'col-lg-6 col-sm-6';
                            }
                        } else {
                            $frutin_woo_product_col_val = 'col-xl-3 col-lg-4 col-sm-6';
                        }
                    }
                    ?>

                    <?php foreach ( $related_products as $related_product ) : ?>
                        <div class="<?php echo esc_attr($frutin_woo_product_col_val) ?>">
                            <?php
                                $post_object = get_post( $related_product->get_id() );

                                setup_postdata( $GLOBALS['post'] =& $post_object );

                                wc_get_template_part( 'content', 'product' );
                            ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div> 
            <?php 
            if ($frutin_woo_relproduct_slider == 1) { ?>
                <button data-slider-prev="#reletedProductSlider" class="slider-arrow slider-prev"><i class="far fa-arrow-left"></i></button>
                <button data-slider-next="#reletedProductSlider" class="slider-arrow slider-next"><i class="far fa-arrow-right"></i></button>
            <?php } ?>
        </div>
    </div>
<?php endif;

wp_reset_postdata();