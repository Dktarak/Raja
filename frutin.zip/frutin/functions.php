<?php
/**
 * @Packge     : Frutin
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Include File
 *
 */

// Constants
require_once get_parent_theme_file_path() . '/inc/frutin-constants.php';

//theme setup
require_once FRUTIN_DIR_PATH_INC . 'theme-setup.php';

//essential scripts
require_once FRUTIN_DIR_PATH_INC . 'essential-scripts.php';

// Woo Hooks
require_once FRUTIN_DIR_PATH_INC . 'woo-hooks/frutin-woo-hooks.php';

// Woo Hooks Functions
require_once FRUTIN_DIR_PATH_INC . 'woo-hooks/frutin-woo-hooks-functions.php';

// plugin activation
require_once FRUTIN_DIR_PATH_FRAM . 'plugins-activation/frutin-active-plugins.php';

// theme dynamic css
require_once FRUTIN_DIR_PATH_INC . 'frutin-commoncss.php';

// meta options
require_once FRUTIN_DIR_PATH_FRAM . 'frutin-meta/frutin-config.php';

// page breadcrumbs
require_once FRUTIN_DIR_PATH_INC . 'frutin-breadcrumbs.php';

// sidebar register
require_once FRUTIN_DIR_PATH_INC . 'frutin-widgets-reg.php';

//essential functions
require_once FRUTIN_DIR_PATH_INC . 'frutin-functions.php';

// helper function
require_once FRUTIN_DIR_PATH_INC . 'wp-html-helper.php';

// Demo Data
require_once FRUTIN_DEMO_DIR_PATH . 'demo-import.php';

// pagination
require_once FRUTIN_DIR_PATH_INC . 'wp_bootstrap_pagination.php';

// frutin options
require_once FRUTIN_DIR_PATH_FRAM . 'frutin-options/frutin-options.php';

// hooks
require_once FRUTIN_DIR_PATH_HOOKS . 'hooks.php';

// hooks funtion
require_once FRUTIN_DIR_PATH_HOOKS . 'hooks-functions.php';
