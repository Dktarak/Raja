<?php
// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit();
}
/**
 * @Packge     : Frutin
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// enqueue css
function frutin_common_custom_css(){
	wp_enqueue_style( 'frutin-color-schemes', get_template_directory_uri().'/assets/css/color.schemes.css' );

    $CustomCssOpt  = frutin_opt( 'frutin_css_editor' );
	if( $CustomCssOpt ){
		$CustomCssOpt = $CustomCssOpt;
	}else{
		$CustomCssOpt = '';
	}

    $customcss = "";
    
    if( get_header_image() ){
        $frutin_header_bg =  get_header_image();
    }else{
        if( frutin_meta( 'page_breadcrumb_settings' ) == 'page' ){
            if( ! empty( frutin_meta( 'breadcumb_image' ) ) ){
                $frutin_header_bg = frutin_meta( 'breadcumb_image' );
            }
        }
    }
    
    if( !empty( $frutin_header_bg ) ){
        $customcss .= ".breadcumb-wrapper{
            background-image:url('{$frutin_header_bg}')!important;
        }";
    }
    
	// theme color
	$frutinthemecolor = frutin_opt('frutin_theme_color');

    if( !empty( $frutinthemecolor ) ){
        list($r, $g, $b) = sscanf( $frutinthemecolor, "#%02x%02x%02x");

        $frutin_real_color = $r.','.$g.','.$b;
        if( !empty( $frutinthemecolor ) ) {
            $customcss .= ":root {
            --theme-color: rgb({$frutin_real_color});
            }";
        }
    }

	if( !empty( $CustomCssOpt ) ){
		$customcss .= $CustomCssOpt;
	}

    wp_add_inline_style( 'frutin-color-schemes', $customcss );
}
add_action( 'wp_enqueue_scripts', 'frutin_common_custom_css', 100 );