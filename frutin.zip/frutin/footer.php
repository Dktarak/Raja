<?php
/**
 * @Packge     : Frutin
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
    
    /**
    *
    * Hook for Footer Content
    *
    * Hook frutin_footer_content
    *
    * @Hooked frutin_footer_content_cb 10
    *
    */
    do_action( 'frutin_footer_content' );


    /**
    *
    * Hook for Back to Top Button
    *
    * Hook frutin_back_to_top
    *
    * @Hooked frutin_back_to_top_cb 10
    *
    */
    do_action( 'frutin_back_to_top' );

    /**
    *
    * frutin grid lines
    *
    * Hook frutin_grid_lines
    *
    * @Hooked frutin_grid_lines_cb 10
    *
    */
    do_action( 'frutin_grid_lines' );

    wp_footer();
    ?>
</body>
</html>