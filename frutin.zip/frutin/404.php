<?php
/**
 * @Packge     : Frutin
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit();
    }

    if( class_exists( 'ReduxFramework' ) ) {
        $frutin404title     = frutin_opt( 'frutin_error_title' );
        $frutin404description  = frutin_opt( 'frutin_error_description' );
        $frutin404btntext      = frutin_opt( 'frutin_error_btn_text' );
    } else {
        $frutin404title     = __( 'OooPs! Page Not Found', 'frutin' );
        $frutin404description  = __( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'frutin' );
        $frutin404btntext      = __( ' Back To Home', 'frutin');

    }

    // get header //
    get_header(); ?>

    <section class="space">
        <div class="container">
            <div class="error-img">
                <?php if(!empty(frutin_opt('frutin_error_img', 'url' ) )): ?>
                    <img src="<?php echo esc_url( frutin_opt('frutin_error_img', 'url' ) ) ?>" alt="<?php echo esc_attr__('404 image', 'frutin'); ?>">
                <?php else: ?>
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/error.svg" alt="<?php echo esc_attr__('404 image', 'frutin'); ?>">
                <?php endif; ?>
            </div>
            <div class="error-content">
                <h2 class="error-title"><?php echo wp_kses_post( $frutin404title ); ?></h2>
                <p class="error-text"><?php echo esc_html( $frutin404description ); ?></p>
                <div class="btn-group justify-content-center">
                    <a href="<?php echo esc_url( home_url('/') ); ?>" class="th-btn error-btn"><i class="fal fa-home me-2"></i><?php echo esc_html( $frutin404btntext ); ?></a>
                </div>
            </div>
        </div>
    </section>
    
    <?php
    //footer
    get_footer();