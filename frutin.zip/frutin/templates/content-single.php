<?php
/**
 * @Packge     : Frutin
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    frutin_setPostViews( get_the_ID() );

    ?>
    <div <?php post_class(); ?>>
    <?php
        if( class_exists('ReduxFramework') ) {
            $frutin_post_details_title_position = frutin_opt('frutin_post_details_title_position');
        } else {
            $frutin_post_details_title_position = 'header';
        }

        $allowhtml = array(
            'p'         => array(
                'class'     => array()
            ),
            'span'      => array(),
            'a'         => array(
                'href'      => array(),
                'title'     => array()
            ),
            'br'        => array(),
            'em'        => array(),
            'strong'    => array(),
            'b'         => array(),
        );
        // Blog Post Thumbnail
        do_action( 'frutin_blog_post_thumb' );
        
        echo '<div class="blog-content">';

            // Blog Post Meta
            do_action( 'frutin_blog_post_meta' );

            if( $frutin_post_details_title_position != 'header' ) {
                echo '<h2 class="blog-title">'.wp_kses( get_the_title(), $allowhtml ).'</h2>';
            }

            if( get_the_content() ){

                the_content();
                // Link Pages
                frutin_link_pages();
            }  

            if( class_exists('ReduxFramework') ) {
                $frutin_post_details_share_options = frutin_opt('frutin_post_details_share_options');
                $frutin_display_post_tags = frutin_opt('frutin_display_post_tags');
                $frutin_author_options = frutin_opt('frutin_post_details_author_desc_trigger');
            } else {
                $frutin_post_details_share_options = false;
                $frutin_display_post_tags = false;
                $frutin_author_options = false;
            }
            
            $frutin_post_tag = get_the_tags();
            
            if( ! empty( $frutin_display_post_tags ) || ( ! empty($frutin_post_details_share_options )) ){
                echo '<div class="share-links clearfix">';
                    echo '<div class="row justify-content-between">';
                        if( is_array( $frutin_post_tag ) && ! empty( $frutin_post_tag ) ){
                            if( count( $frutin_post_tag ) > 1 ){
                                $tag_text = __( 'Tags:', 'frutin' );
                            }else{
                                $tag_text = __( 'Tag:', 'frutin' );
                            }
                            if($frutin_display_post_tags){
                                echo '<div class="col-md-auto">';
                                    echo '<span class="share-links-title">'.esc_html($tag_text).'</span>';
                                    echo '<div class="tagcloud">';
                                        foreach( $frutin_post_tag as $tags ){
                                            echo '<a href="'.esc_url( get_tag_link( $tags->term_id ) ).'">'.esc_html( $tags->name ).'</a>';
                                        }
                                    echo '</div>';
                                echo '</div>';
                            }
                        }
    
                        /**
                        *
                        * Hook for Blog Details Share Options
                        *
                        * Hook frutin_blog_details_share_options
                        *
                        * @Hooked frutin_blog_details_share_options_cb 10
                        *
                        */
                        do_action( 'frutin_blog_details_share_options' );
    
                    echo '</div>';
    
                echo '</div>';    
            }  

        echo '</div>';

   

       

    echo '</div>'; 

        /**
        *
        * Hook for Blog Authro Bio
        *
        * Hook frutin_blog_details_author_bio
        *
        * @Hooked frutin_blog_details_author_bio_cb 10
        *
        */
        do_action( 'frutin_blog_details_author_bio' );

        /**
        *
        * Hook for Blog Details Comments
        *
        * Hook frutin_blog_details_comments
        *
        * @Hooked frutin_blog_details_comments_cb 10
        *
        */
        do_action( 'frutin_blog_details_comments' );
